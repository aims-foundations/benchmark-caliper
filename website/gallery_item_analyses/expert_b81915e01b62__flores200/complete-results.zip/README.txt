CALIPER SIX-SCORE ITEM ANALYSIS — OFFLINE RESULTS PACKAGE

Snapshot: pilot-complete

Extract the whole ZIP and open report.html in a browser. It needs no server or
internet connection. Keep companion file names so relative links still work.
The report shows one row per selected item and six 1–5 deployment-alignment scores:
Input Ontology, Input Content, Input Form, Output Ontology, Output Content,
and Output Form. Open each score to inspect its explanation, evidence, and gaps.
Unknown means insufficient evidence. Operational errors and pending items are
separate states. An item can be complete while some scores remain Unknown.

items.csv contains only selected items, selection flags, scores, explanations,
evidence, and information gaps. Selected pending items and errors remain visible
in both the report and CSV. Before a selection is recorded, they contain no item
rows. audit/items.jsonl retains the full prepared dataset, including unselected
items, unchanged. summary.json records the selected-item score
distributions, selected progress, and full prepared-population counts. No item
rank or combined benchmark score is computed. A completed pilot does not imply
completion of the full prepared snapshot or establish benchmark-wide coverage.

classifier_spec.json contains the fixed six-dimension rubric, shared deployment
requirements, benchmark documentation, and their source references. Context is
assembled once from saved evidence; one primary model call returns all six
judgments for an item. Repairs and retries add calls. Original benchmark scores
are not used as item-scoring evidence and are never overwritten by item scores.
audit/evidence.json retains the original evidence; original_assessment.json
contains benchmark scoring when supplied. original_benchmark_report.pdf is
included only when a saved original PDF exists. Missing assessments are explicit.

INDEPENDENT HUMAN REVIEW
Make a separately named copy of review/blank_review.csv for each reviewer.
Share that blank copy with classifier_spec.json and the relevant evidence,
without model predictions or other reviewers' annotations. Enter 1–5 or unknown
for each dimension, a justification, evidence, and information gaps. Unknown
requires an explanation of the missing information; blank scores mean unreviewed.
Keep reviewers' files separate. Root review.csv is preserved exactly and may
already contain human annotations. It is not necessarily a blank template.
audit/review_comparison.json, when present, records agreement and per-dimension
numeric error; report.html states whether the comparison matches saved inputs.

AUDIT AND REPRODUCIBILITY
manifest.json identifies the run, timestamps, scope, status, selected IDs, model,
available usage, member sizes, SHA-256 checksums, and missing artifacts. The
audit/ folder contains saved input items, context provenance, frozen scoring
prompts, exact requests, raw responses, results, configuration, and usage logs.
Some artifacts appear only after scoring starts. Context assembly does not
require a context-generation model request. Missing logs mean unavailable,
not zero calls. Usage totals can omit unknown usage from failed or cancelled
provider calls and are not guaranteed billing totals. Previews are not execution.
No historical request is reconstructed as an exact log. Future model calls
may produce different judgments. Credentials and private website access files
are outside the artifact allowlist and are not included.
